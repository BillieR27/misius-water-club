var KEY="misiu-water-v1",S={goal:2500,rem:false,every:60,days:{}},lastRem=Date.now(),lastP=0;
try{var raw=localStorage.getItem(KEY);if(raw)S=Object.assign(S,JSON.parse(raw))}catch(e){}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
function dk(d){d=d||new Date();return d.getFullYear()+"-"+("0"+(d.getMonth()+1)).slice(-2)+"-"+("0"+d.getDate()).slice(-2)}
function $(i){return document.getElementById(i)}
function today(){var k=dk();return S.days[k]||(S.days[k]=[])}
function total(a){return a.reduce(function(s,e){return s+e.ml},0)}
var M={
0:["Pij wodę, Misiu! 🐻 Your Thai girl is watching… 👀","ดื่มน้ำนะ (duem nam na) — drink water, my handsome bear.","Good morning, Misiu! First sip, then I’m allowed to miss you.","Dzień dobry, Misiaczku! Water first. Pierogi later. 🥟"],
1:["Little Bear is getting hydrated! 💧","Dobrze, Misiu! Keep it flowing, kochanie.","Sip sip! Hydrated men are 73% more handsome. (I made that up.)"],
2:["Halfway there, Misiu! 🐻💙","เก่งมาก (geng maak) — so good! Keep going.","Half a bear, half a goal. Na zdrowie! 🥂"],
3:["Almost there, handsome! 😘","Prawie, prawie, Misiu! Don’t stop now.","สู้ๆ (suu suu)! One more push for your girl."],
4:["Good boy! Your Thai girl is proud of you! ❤️","Brawo, Misiu! Goal done. You deserve a hug (and maybe pad thai).","Cel osiągnięty! 100% hydrated, 100% mine. 💕"]};
var NUDGE=["Misiu… your water bottle misses you. So do I. 🥺","Psst, handsome. Water. Now. Kocham Cię!","Drink up, Misiaczku — dehydrated bears get grumpy. 🐻","คิดถึงนะ (khit thueng na)! Miss you. Take a sip for me.","Wanna look good for your girl? Hydrate. 😏","Hey Misiu, Thailand is hot, Poland is cold, but you still need water. 💧"];
function pick(a){return a[Math.floor(Math.random()*a.length)]}
function tier(p){return p>=100?4:p>=75?3:p>=50?2:p>=25?1:0}
function toast(t){var e=$("toast");e.textContent=t;e.classList.add("on");clearTimeout(toast.t);toast.t=setTimeout(function(){e.classList.remove("on")},3800)}
function hearts(n){if(matchMedia("(prefers-reduced-motion:reduce)").matches)return;for(var i=0;i<n;i++){var h=document.createElement("span");h.className="heart";h.textContent=pick(["❤️","💙","💕","🐻","💧"]);h.style.left=Math.random()*90+"%";h.style.animationDelay=Math.random()*.6+"s";document.body.appendChild(h);setTimeout(function(x){x.remove()}.bind(null,h),3200)}}
function render(msg){
 var a=today(),t=total(a),p=Math.round(t/S.goal*100),cp=Math.min(p,100);
 $("ml").textContent=t;$("goal").textContent=S.goal;$("pct").textContent=p+"%";$("bar").style.width=cp+"%";
 var h=cp/100*190;$("lvl").setAttribute("y",228-h);
 if(msg)$("msg").textContent=msg;else if(!$("msg").textContent)$("msg").textContent=pick(M[tier(p)]);
 $("log").innerHTML=a.length?a.slice().reverse().map(function(e,i){var d=new Date(e.t);return '<div class="row"><span>'+("0"+d.getHours()).slice(-2)+":"+("0"+d.getMinutes()).slice(-2)+" · "+e.ml+' ml</span><button class="x" data-i="'+(a.length-1-i)+'" aria-label="Remove entry">✕</button></div>'}).join(""):'<div class="empty">No sips yet. Your bear is thirsty 🐻</div>';
 var H="";for(var i=6;i>=0;i--){var d=new Date();d.setDate(d.getDate()-i);var v=total(S.days[dk(d)]||[]);var q=Math.min(v/S.goal,1);H+='<div class="'+(v>=S.goal?"full":"")+'"><span>'+(v?v:"")+'</span><b style="height:'+Math.max(q*86,4)+'px"></b><span>'+["Su","Mo","Tu","We","Th","Fr","Sa"][d.getDay()]+"</span></div>"}
 $("hist").innerHTML=H;lastP=p;
}
function add(ml){
 var before=Math.round(total(today())/S.goal*100);
 today().push({t:Date.now(),ml:ml});save();
 var p=Math.round(total(today())/S.goal*100),tb=tier(before),ta=tier(p);
 render(pick(M[ta]));
 if(ta>tb){toast(M[ta][0]);hearts(ta==4?24:10)}else hearts(3);
 lastRem=Date.now();
}
document.querySelectorAll(".add[data-ml]").forEach(function(b){b.onclick=function(){add(+b.dataset.ml)}});
$("undo").onclick=function(){var a=today();if(a.length){a.pop();save();render("Oops, undone! Misiu keeps it honest. 😇")}};
$("log").onclick=function(e){var i=e.target.dataset&&e.target.dataset.i;if(i!=null){today().splice(+i,1);save();render("Entry removed. Fixed, Misiu! ✏️")}};
$("gear").onclick=function(){$("goalIn").value=S.goal;$("remOn").checked=S.rem;$("remEvery").value=S.every;$("dlg").showModal()};
$("save").onclick=function(){
 var g=parseInt($("goalIn").value,10);if(g>=500&&g<=6000)S.goal=g;
 S.rem=$("remOn").checked;S.every=+$("remEvery").value;save();$("dlg").close();
 if(S.rem&&"Notification"in window&&Notification.permission==="default")Notification.requestPermission();
 lastRem=Date.now();render("Saved! Goal: "+S.goal+" ml. Let’s go, Misiu 💪");
};
function remind(){
 var n=new Date(),h=n.getHours();
 if(dk(n)!==remind.day){remind.day=dk(n);$("msg").textContent="";render()}
 if(!S.rem||h<8||h>=22||Date.now()-lastRem<S.every*60000)return;
 if(total(today())>=S.goal)return;
 lastRem=Date.now();var t=pick(NUDGE);toast(t);
 if("Notification"in window&&Notification.permission==="granted"){try{new Notification("Misiu’s Water Club 🐻",{body:t})}catch(e){}}
}
remind.day=dk();setInterval(remind,30000);
document.addEventListener("visibilitychange",function(){if(!document.hidden)remind()});
render();
