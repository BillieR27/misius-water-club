# Misiu’s Water Club 🐻💧
A hydration tracker made with love. Static site, no build step.

## Put it on GitHub Pages
1. Create a new repository on GitHub (e.g. `misiu-water-club`).
2. Upload everything in this folder (keep `assets/` as a folder).
3. Repo Settings → Pages → Source: "Deploy from a branch" → `main` / `(root)` → Save.
4. After a minute the site is live at `https://YOUR-USERNAME.github.io/misiu-water-club/`.

## Add to phone home screen
Open the link in Safari (iPhone) or Chrome (Android) → Share/menu → "Add to Home Screen".
Reminders only appear while the app is open.

## Files
- index.html, style.css, app.js: the app
- manifest.webmanifest + assets/: home-screen icon
